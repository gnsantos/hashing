#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define INITIAL_BUFFER_SIZE 100

char* getinput(FILE*);
